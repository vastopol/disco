JavaLC3
=======

A Simple LC-3 (Little Computer 3) implementation in Java.